package ExercicioSeisListaCinco;

public class SomaDosArgumentos {

    private int numeroUm = 10;
    private int numeroDois = 20;
    private int numeroTres = 30;
    

    public int getNumeroUm(){
    return numeroUm;
    }
    public int getNumeroDois(){
    return numeroDois;
    }
    public int getNumeroTres(){
    return numeroTres;
    }
    public int somar(int num1, int num2, int num3){
    int calculo = (num1 + num2 + num3);
    return calculo;
    }
    
}
